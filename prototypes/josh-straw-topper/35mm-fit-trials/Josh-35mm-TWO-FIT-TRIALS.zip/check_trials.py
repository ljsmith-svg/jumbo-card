from pathlib import Path
import zipfile,json
import trimesh,numpy as np
p=Path(__file__).parent
report={}
for hole in [8,10]:
 folder=p/f'{hole}mm-opening'
 scene=trimesh.load(folder/f'Josh-35mm-opening-{hole}mm-TRIAL.3mf',process=False)
 assert len(scene.geometry)==3
 bore=trimesh.creation.cylinder(radius=hole/2-0.01,height=100,sections=192)
 bore.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[1,0,0]));bore.apply_translation([35*35/63.5,12.8904706735,7])
 results={}
 for name,m in scene.geometry.items():
  assert m.is_watertight and m.is_winding_consistent and m.volume>0
  obstruction=trimesh.boolean.intersection([m,bore],engine='manifold')
  assert abs(obstruction.volume)<1e-5
  results[name]={'watertight':True,'winding_consistent':True,'passage_obstruction_volume_mm3':float(obstruction.volume),'z_range_mm':m.bounds[:,2].tolist()}
 assert np.isclose(scene.bounds[1,0]-scene.bounds[0,0],35,atol=0.005)
 assert np.isclose(scene.bounds[1,2],16,atol=1e-4)
 assert np.isclose(scene.geometry['black'].bounds[1,2],14,atol=1e-4)
 report[str(hole)]=results
 print(hole,'mm opening: round-trip, meshes, width, relief and clear bore passed',flush=True)
(p/'export-check.json').write_text(json.dumps(report,indent=2))
with zipfile.ZipFile(p/'Josh-35mm-TWO-FIT-TRIALS.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in p.rglob('*'):
  if f.is_file() and f.suffix in ['.3mf','.stl','.json','.py','.txt'] and f.name!='inspect_outline.py':z.write(f,str(f.relative_to(p)))
print('Package created')
