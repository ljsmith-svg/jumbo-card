from pathlib import Path
import zipfile,json
import numpy as np
import trimesh
p=Path(__file__).parent
s=trimesh.load(p/'Josh-63.5mm-10.2mm-PROTOTYPE.3mf',process=False)
print('3MF round-trip geometries:',len(s.geometry))
assert len(s.geometry)==3 and all(m.is_watertight for m in s.geometry.values())
c=trimesh.creation.cylinder(radius=5.09,height=100,sections=192)
c.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[1,0,0]));c.apply_translation([35,23,8])
results={}
for name,m in s.geometry.items():
 overlap=trimesh.boolean.intersection([m,c],engine='manifold')
 results[name]={'watertight':bool(m.is_watertight),'passage_obstruction_volume_mm3':float(overlap.volume)}
 print(name,results[name]);assert abs(overlap.volume)<1e-5
(p/'export-check.json').write_text(json.dumps(results,indent=2))
with zipfile.ZipFile(p/'Josh-topper-prototype.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in p.iterdir():
  if f.suffix in ['.3mf','.stl','.json','.txt','.py']:z.write(f,f.name)
print('Package created')
