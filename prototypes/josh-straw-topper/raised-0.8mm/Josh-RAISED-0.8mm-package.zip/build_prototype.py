from pathlib import Path
import xml.etree.ElementTree as ET
import math,json,zipfile
import numpy as np
from svgpathtools import parse_path
from shapely.geometry import Polygon, MultiPolygon, LineString
from shapely import make_valid
from shapely.ops import unary_union
from shapely.affinity import affine_transform
import trimesh
OUT=Path(__file__).parent
SRC=Path('/workspace/attachments/57794507-b14b-4ae4-9434-93969d7279c3/Josh.svg')
root=ET.parse(SRC).getroot()
def polygons(g):
 if g.geom_type=='Polygon':return [g] if g.area>1e-9 else []
 return [p for c in getattr(g,'geoms',[]) for p in polygons(c)]
def shape(d):
 result=[]
 for sub in parse_path(d).continuous_subpaths():
  pts=[]
  for seg in sub:
   n=max(2,math.ceil(seg.length(error=1e-4)/0.7))
   pts.extend((seg.point(i/n).real,seg.point(i/n).imag) for i in range(n))
  if len(pts)>2:result.extend(polygons(make_valid(Polygon(pts))))
 return unary_union(result)
raw=[shape(e.attrib['d']) for e in root]
# Path 0 is the exterior white background. Path 1 is the enclosing black silhouette.
bounds=raw[1].bounds; scale=63.5/(bounds[2]-bounds[0])
def transform(g):return affine_transform(g,[scale,0,0,-scale,-bounds[0]*scale,bounds[3]*scale])
body2=transform(raw[1]); body2=unary_union([Polygon(p.exterior) for p in polygons(body2)])
regions={c:Polygon() for c in ['#ffffff','#020202','#f20512']}
for e,g in zip(list(root)[1:],raw[1:]):
 g=transform(g).intersection(body2)
 for c in regions:regions[c]=regions[c].difference(g)
 c=e.attrib['fill'];regions[c]=unary_union([regions[c],g])
def extrude(g,height,z=0):
 import manifold3d as mf
 solids=[]
 for p in polygons(g.simplify(0.003,preserve_topology=True)):
  if p.area < 0.0001:continue
  rings=[np.array(p.exterior.coords)[:-1]]+[np.array(r.coords)[:-1] for r in p.interiors]
  solid=mf.CrossSection(rings,mf.FillRule.EvenOdd).extrude(height).translate([0,0,z])
  if not solid.is_empty():solids.append(solid)
 solid=mf.Manifold.batch_boolean(solids,mf.OpType.Add)
 mesh=solid.to_mesh()
 return trimesh.Trimesh(vertices=np.array(mesh.vert_properties)[:,:3],faces=np.array(mesh.tri_verts),process=False)
base=extrude(body2,16)
hole_x=35.0
cutter=trimesh.creation.cylinder(radius=5.1,height=100,sections=192)
cutter.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]));cutter.apply_translation([hole_x,23,8])
base=trimesh.boolean.difference([base,cutter],engine='manifold')
black_inlay=extrude(regions['#020202'],0.4,15.6)
base=trimesh.boolean.difference([base,black_inlay],engine='manifold')
parts={}
for color,name in [('#ffffff','white'),('#020202','black'),('#f20512','red')]:
 top=black_inlay if name=='black' else extrude(regions[color],0.8,16)
 print(name,'top',top.is_watertight,top.is_volume,flush=True)
 parts[name]=trimesh.boolean.union([base,top],engine='manifold') if name=='white' else top
 parts[name].export(OUT/f'{name}.stl')
report={'units':'mm','width':63.5,'height':body2.bounds[3]-body2.bounds[1],'body_thickness':16,'raised_height':0.8,'black_top_z':16.0,'red_white_top_z':16.8,'hole_diameter':10.2,'hole_center_from_left':hole_x,'parts':{}}
for name,m in parts.items():
 report['parts'][name]={'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'volume_mm3':float(m.volume),'triangles':len(m.faces),'bounds':m.bounds.tolist()}
 assert m.is_watertight and m.is_winding_consistent and m.volume>0
report['color_area_coverage_error_mm2']=float(body2.symmetric_difference(unary_union(list(regions.values()))).area)
# Standards-based multipart 3MF, with material labels. No printer-specific profile or G-code.
NS='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
ET.register_namespace('',NS)
def el(tag,attrib={},parent=None):
 x=ET.Element('{'+NS+'}'+tag,attrib) if parent is None else ET.SubElement(parent,'{'+NS+'}'+tag,attrib)
 return x
model=el('model',{'unit':'millimeter','{http://www.w3.org/XML/1998/namespace}lang':'en-US'});res=el('resources',parent=model)
mat=el('basematerials',{'id':'1'},res)
for name,c in [('white','#FFFFFFFF'),('black','#020202FF'),('red','#F20512FF')]:el('base',{'name':name,'displaycolor':c},mat)
for idx,(name,m) in enumerate(parts.items()):
 obj=el('object',{'id':str(idx+2),'type':'model','name':name,'pid':'1','pindex':str(idx)},res)
 mesh=el('mesh',parent=obj);vs=el('vertices',parent=mesh);ts=el('triangles',parent=mesh)
 for v in m.vertices:el('vertex',dict(zip(['x','y','z'],[f'{a:.7f}' for a in v])),vs)
 for f in m.faces:el('triangle',dict(zip(['v1','v2','v3'],map(str,f))),ts)
assembly=el('object',{'id':'5','type':'model','name':'Josh straw topper - UNTESTED'},res);cs=el('components',parent=assembly)
for i in [2,3,4]:el('component',{'objectid':str(i)},cs)
build=el('build',parent=model);el('item',{'objectid':'5'},build)
with zipfile.ZipFile(OUT/'Josh-RAISED-0.8mm-PROTOTYPE.3mf','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
 z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
 z.writestr('3D/3dmodel.model',ET.tostring(model,encoding='utf-8',xml_declaration=True))
(OUT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
